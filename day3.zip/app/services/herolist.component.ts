import { Component, OnInit } from "@angular/core";
import { HeroData } from "./herodata.service";

@Component({
    selector : 'hero-list',
    template : `
    <hero-nav></hero-nav>
    <table class='table table-responsive table-striped'>
        <thead>
            <tr>
                <td>Sl #</td>
                <td>Title</td>
                <td>Full Name</td>
                <td>City</td>
                <td>Poster</td>
                <td>Ticket Price</td>
                <td>Release Date</td>
            </tr>
        </thead>
        <tbody>
            <tr *ngFor='let hero of heroeslist.herodata'>
                <td>{{ hero.sl }}</td>
                <td>{{ hero.title | uppercase | gen : hero.gender }}</td>
                <td>{{ hero.firstname+' '+hero.lastname }}</td>
                <td>{{ hero.city | lowercase }}</td>
                <td> <img [src]='hero.poster' width='40' /></td>
                <td>{{ hero.ticketprice | currency : 'INR ': true : '3.3-4' }}</td>
                <td>{{ hero.releasedate | date : 'dd-MMM-yyyy' }}</td>
            </tr>
        </tbody>
    </table>
    `
})
export class HeroListComponent implements OnInit {

heroeslist =  [];  

constructor(private hs:HeroData){}

ngOnInit(){
      this.hs.getData().subscribe(res => {
          this.heroeslist = res
      })
};

}