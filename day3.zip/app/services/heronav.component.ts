import { Component, OnInit } from "@angular/core";
import { HeroData } from "./herodata.service";

@Component({
    selector : 'hero-nav',
    template : `
       <ul class='nav navbar-nav'>
           <li *ngFor='let heroitem of heroeslist.herodata'>
               <a href='#'>{{ heroitem.title }}</a>
           </li>
       </ul>
    `
})
export class HeroNavComponent implements OnInit {
    /*
    herodata:any;
    constructor( hd:HeroData){
        this.herodata = hd.getData();
    }
    */
    heroeslist = [];
    constructor(private hd: HeroData) {
    }
    ngOnInit() {
        this.hd.getData().subscribe(res => this.heroeslist = res );
    }
}