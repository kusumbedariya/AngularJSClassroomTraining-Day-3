import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { GenPipe } from './formaters/gen.pipe';
import { HeroListComponent } from './services/herolist.component';
import { HeroNavComponent } from './services/heronav.component';
import { HeroData } from './services/herodata.service';
import { HttpClientModule } from '@angular/common/http';


@NgModule({
  declarations: [ 
    HeroNavComponent,
    GenPipe,
    HeroListComponent,
  ],
  imports: [
    BrowserModule, FormsModule, HttpClientModule
  ],
  providers: [HeroData],
  bootstrap: [HeroListComponent]
})
export class AppModule { }
