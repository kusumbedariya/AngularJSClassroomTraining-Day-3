import { Pipe, PipeTransform } from "@angular/core";

@Pipe({
    name : 'gen'
})
export class GenPipe implements PipeTransform {
    transform(value: any, arg?: any): any {
        if(arg === 'male'){
            return 'Mr. '+value ;
        }else{
            return 'Mrs. '+value ;
        }
    }
}
