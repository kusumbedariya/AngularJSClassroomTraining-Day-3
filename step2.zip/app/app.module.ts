import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { GenPipe } from './formaters/gen.pipe';
import { HeroListComponent } from './services/herolist.component';
import { HeroNavComponent } from './services/heronav.component';


@NgModule({
  declarations: [ 
    HeroListComponent, 
    GenPipe,
    HeroNavComponent],
  imports: [
    BrowserModule, FormsModule
  ],
  providers: [],
  bootstrap: [HeroListComponent]
})
export class AppModule { }
