import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { BuiltinComponent } from './formaters/builtin-pipes.component';


@NgModule({
  declarations: [ BuiltinComponent ],
  imports: [
    BrowserModule, FormsModule
  ],
  providers: [],
  bootstrap: [BuiltinComponent]
})
export class AppModule { }
